package com.example.bottomtab;

public class Data{
    String key;
    String value;
    Data(String key, String value){
        this.key = key;
        this.value = value;
    }
}
